/* stuff for receiving commands etc */

/* (c) copyright fenugrec 2016
 * GPLv3
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

#include "stypes.h"

void send_message(u8 *buf, u32 msglen);

//#define KLINE
#if defined(KLINE)
/****************************
 *
 * K-Line functions
 *
 ****************************/
void kline_send_message(u8 *msg, u32 len);
enum iso_prc kline_get_message(u8 *msg, u8 newbyte);
//void cmd_init(u8 brrdiv);
//void cmd_loop(void);
#endif

#ifndef KLINE
/****************************
 *
 * CAN / ISO15765 functions
 *
 ****************************/
int can_send_message(u8 *msg, u32 len);
int can_get_message(u8 *msg);
//void can_cmd_loop(void);
#endif

void cmd_loop(void);
